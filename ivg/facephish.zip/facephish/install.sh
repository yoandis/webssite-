#!/bin/bash

system=$(uname -o)
arch=$(uname -m)

if [[ "${system}" == "Android" ]]; then
    apt="pkg"
    ssh="openssh"
    nodejs="nodejs"
    npm="nodejs"
    ngrok="/data/data/com.termux/files/usr/bin"
    bin="/data/data/com.termux/files/usr/bin"
else
    apt="apt"
    ssh="ssh"
    nodejs="nodejs"
    npm="npm"
    ngrok="/usr/bin"
    bin="/usr/bin"
fi

checkgit=$(command -v git)
checkcurl=$(command -v curl)
checkwget=$(command -v wget)
checkssh=$(command -v ssh)
checknodejs=$(command -v node)
checknpm=$(command -v npm)
checkphp=$(command -v php)
checklt=$(command -v lt)
checkngrok=$(command -v ngrok)
checkcloud=$(command -v cloudflared)

if [[ "${checkgit}" == "" ]]; then
    ${apt} install git -y
fi
if [[ "${checkcurl}" == "" ]]; then
    ${apt} install curl -y
fi
if [[ "${checkwget}" == "" ]]; then
    ${apt} install wget -y
fi
if [[ "${checkssh}" == "" ]]; then
    ${apt} install ${ssh} -y
fi
if [[ "${checknodejs}" == "" ]]; then
    ${apt} install ${nodejs} -y
fi
if [[ "${checknpm}" == "" ]]; then
    ${apt} install ${npm} -y
fi
if [[ "${checkphp}" == "" ]]; then
    ${apt} install php -y
fi
if [[ "${checklt}" == "" ]]; then
    npm install -g localtunnel
    if [[ "${system}" == "Android" ]]; then
        rm /data/data/com.termux/files/usr/lib/node_modules/localtunnel/node_modules/openurl/openurl.js
        cp .openurl.js /data/data/com.termux/files/usr/lib/node_modules/localtunnel/node_modules/openurl/openurl.js
    fi
fi
if [[ "${checkcloud}" == "" ]]; then
    if [[ ("${arch}" == *"arm"*) || ("${arch}" == *"Android"*) ]]; then
        wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm -O ${bin}/cloudflared
        chmod 777 ${bin}/cloudflared
    elif [[ "${arch}" == *"aarch64"* ]]; then
        wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64 -O ${bin}/cloudflared
        chmod 777 ${bin}/cloudflared
    elif [[ "${arch}" == *"x86_64"* ]]; then
        wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -O ${bin}/cloudflared
        chmod 777 ${bin}/cloudflared
    else
        wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-386 -O ${bin}/cloudflared
        chmod 777 ${bin}/cloudflared
    fi
fi
if [[ "${checkngrok}" == "" ]]; then
    wget https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-arm.tgz -O ${ngrok}/ngrok-v3-stable-linux-arm.tgz
    tar xzvf ${ngrok}/ngrok-v3-stable-linux-arm.tgz
    rm ${ngrok}/ngrok-v3-stable-linux-arm.tgz
    mv ngrok ${ngrok}
    chmod 777 ${ngrok}/ngrok
    read -p "ngrok authtoken > " authtoken
    ngrokauthtoken=$(echo "${authtoken}" | cut -d " " -f 1)
    if [[ "${ngrokauthtoken}" == "ngrok" ]]; then
        ${authtoken}
    else
        ngrok config add-authtoken ${authtoken}
    fi
fi
