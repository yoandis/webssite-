#!/bin/bash
port="8080"
ssh -R 80:localhost:${port} nokey@localhost.run
